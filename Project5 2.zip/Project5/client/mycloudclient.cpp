#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sstream>
#include <string>
#include <vector>
#include <fstream>

extern "C" {
    #include "csapp.h"
}

using namespace std;

typedef struct request_struct {
    uint32_t type;
    uint32_t secret;
    char filename[80];
    uint32_t size;
    char filedata[100*1024];
} request;

typedef struct response_struct {
    uint32_t status;
    uint32_t size;
    char data[100*1024];
} response;

int req_type(string name) {
    if (name == "cget")           return  0;
    else if (name == "cput")      return  1;
    else if (name == "cdelete")   return  2;
    else if (name == "clist")     return  3;
    else                          return  4;
}

int req_byte(string name, uint32_t size) {
    if (size > 102492) cerr << "Invalid size" << endl;
    else if (name == "cget")      return  88;
    else if (name == "cput")      return  92+size;
    else if (name == "cdelete")   return  88;
    else if (name == "clist")     return  8;
    return  0;
}

int main(int argc, char **argv)
{
    int clientfd, port;         // client file descriptor and port number
    char *host;
    struct stat st;             // for file size
    string inputLine = "";
    rio_t rio;                  // rio for TCP sockets
    request req;                // request struct from client
    response resp;              // response struct from server
    
    if (argc != 4) { fprintf(stderr, "usage: %s <ServerName> <TCPport> <SecretKey>\n", argv[0]); exit(0); }
    
    host = argv[1];
    port = atoi(argv[2]);
    req.secret = htonl(atoi(argv[3]));
    req.size = 0;
    
    clientfd = Open_clientfd(host, port);
    Rio_readinitb(&rio, clientfd);
    cout << "Client socket created...\n> ";
    
    getline(cin, inputLine);
    while (inputLine != "quit" && !cin.eof()) {
        vector<string> commands;
        stringstream iss(inputLine);
        for(string inputLine; iss >> inputLine;) commands.push_back(inputLine);
        
        if (commands.size() == 0) goto PROMPT;
        
        else if (req_type(commands[0]) < 3 && commands.size() != 2) {
            fprintf(stderr, "usage: %s <FileName>\n", commands[0].c_str()); goto PROMPT; }
        
        else if (req_type(commands[0]) == 3 && commands.size() != 1) {
            fprintf(stderr, "usage: %s: Too many arguments\n", commands[0].c_str()); goto PROMPT; }
        
        else if (req_type(commands[0]) == 4) { cerr << "Invalid command" << endl; goto PROMPT; }
        
        //-----------Make Request Struct-----------
        req.type = htonl(req_type(commands[0]));
        if (commands.size() == 2) strcpy(req.filename, commands[1].c_str());
        
        if (commands[0] == "cput") {
            FILE * fileToSend = fopen (req.filename, "rb");
            
            if(fileToSend == NULL || stat(req.filename, &st) != 0) {
                cerr << "Error opening file" << endl; goto PROMPT; }
            else if (st.st_size > 102400) {
                cerr << "File exceeds 100KB" << endl; goto PROMPT; }
            else {
                req.size = htonl(st.st_size);
                fread (req.filedata,  sizeof(char), st.st_size, fileToSend);
                fclose (fileToSend);
            }
        }
        
        //-----------Send Request-----------
        Rio_writen(clientfd, &req, req_byte(commands[0], st.st_size));
        
        
        //-----------Recieve Response-----------
        Rio_readn(clientfd, &resp.status, 4);
        
        if (ntohl(resp.status) == 0) {      // Success
            if (commands[0] == "cget") {
                Rio_readn(clientfd, &resp.size, 4);
                Rio_readn(clientfd, &resp.data, ntohl(resp.size));
                
                FILE * fileToReceive = fopen (req.filename, "wb");
                fwrite (resp.data, sizeof(char), ntohl(resp.size), fileToReceive);
                fclose (fileToReceive);
            }
            
            if (commands[0] == "clist") {
                Rio_readn(clientfd, &resp.size, 4);
                for(int i = 0; i < ntohl(resp.size); i++) {
                    char buf[80];
                    Rio_readn(clientfd, &buf, 80);
                    cout << i << "] "<< buf << endl;
                }
            }
        }
        else if (ntohl(resp.status)  == 1) cerr << "Error" << endl;
        else if (ntohl(resp.status) == 2) {
            cout << "Incorrect Secret Key";
            break;
        }
        
        // Clear struct and reassign key
        req = {};
        resp = {};
        req.secret = htonl(atoi(argv[3]));
        
        PROMPT:
        cout << "> ";
        getline(cin, inputLine);
    }
    
    req.type = htonl(req_type("quit"));
    Rio_writen(clientfd, &req.type, 4);
    Rio_writen(clientfd, &req.secret, 4);
    Close(clientfd);
    if (inputLine != "quit") cout << endl;
    exit(0);
}
