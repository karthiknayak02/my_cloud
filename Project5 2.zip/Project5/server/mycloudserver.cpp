#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <vector>
#include <fstream>
#include <sys/types.h>
#include <dirent.h>

extern "C" {
    #include "csapp.h"
}

using namespace std;

typedef struct request_struct {
    uint32_t type;
    uint32_t secret;
    char filename[80];
    uint32_t size;
    char filedata[100*1024];
} request;

typedef struct response_struct {
    uint32_t status;
    uint32_t size;
    char data[100*1024];
} response;

string typeToString(int num) {
    switch (num) {
        case 0:
            return  "cget";
        case 1:
            return  "cput";
        case 2:
            return  "cdelete";
        case 3:
            return  "clist";
        default:
            return "quit";
    }
}


int main(int argc, char **argv)
{
    int listenfd, connfd, port;
    uint32_t secret;
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;
    char client_hostname[MAXLINE], client_port[MAXLINE];
    unsigned char isFile = 0x8;
    string req_type, list_line;
    request req;                // request struct from client
    response resp;              // response struct from server
    struct stat st;             // for file size
    char buf[80];
    DIR *dir;
    struct dirent *dirEntry;
    bool client_connected;

    if (argc != 3) {
        fprintf(stderr, "usage: %s <TCPport> <SecretKey>\n", argv[0]);
        exit(0);
    }
    
    port = atoi(argv[1]);
    secret = atoi(argv[2]);
    
    listenfd = Open_listenfd(port);
    cout << "Server socket created..." << endl;

    clientlen = sizeof(struct sockaddr_storage);
    
    while ((connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen))) {
        getnameinfo((SA *) &clientaddr, clientlen, client_hostname, MAXLINE,
                    client_port, MAXLINE, 0);
        printf("Connection accepted from (%s, %s)\n", client_hostname, client_port);
        
        client_connected = true;
        while(client_connected) {
            //-----------Recieve Request-----------
            Rio_readn(connfd, &req.type, 4);
            Rio_readn(connfd, &req.secret, 4);
            req_type = typeToString(ntohl(req.type));
            if (req_type != "clist") Rio_readn(connfd, &req.filename, 80);
            if (req_type == "cput") {
                Rio_readn(connfd, &req.size, 4);
                Rio_readn(connfd, &req.filedata, ntohl(req.size));
            }
            if (req_type == "quit") {
                client_connected = false;
                break;
            }
            
            //-----------Make Response Struct-----------
            if (secret == ntohl(req.secret) && req_type != "quit") {
                resp.status = htonl(0);
                
                if (req_type == "cput") {
                    FILE * fileToReceive = fopen (req.filename, "wb");
                    fwrite (req.filedata, sizeof(char), ntohl(req.size), fileToReceive);
                    fclose (fileToReceive);
                }
                
                else if (req_type == "cget") {
                    resp.status = htonl(1);
                    FILE * fileToSend;
                    fileToSend = fopen (req.filename, "rb");
                    
                    if(fileToSend == NULL || stat(req.filename, &st) != 0)
                        cout << "Error opening file" << endl;
                    
                    else if (st.st_size > 102400)
                        cout << "File exceeds 100KB" << endl;
                    
                    else {
                        req.size = htonl(st.st_size);
                        fread (req.filedata,  sizeof(char), st.st_size, fileToSend);
                        fclose (fileToSend);
                        resp.status = htonl(0);
                    }
                }
                
                else if (req_type == "cdelete" && remove (req.filename) != 0) resp.status = htonl(1);
                
                else if (req_type == "clist") {
                    dir = opendir (".");
                    vector<string> wdLines;
                    
                    Rio_writen(connfd, &resp.status, 4);
                    while ((dirEntry = readdir (dir))) if (dirEntry->d_type == isFile) {
                        wdLines.push_back(dirEntry->d_name);
                    }
                    closedir (dir);

                    resp.size = htonl(wdLines.size());
                    Rio_writen(connfd, &resp.size, 4);
                    
                    for(int i = 0; i < wdLines.size(); i++) {
                        strncpy(buf, wdLines[i].c_str(), 80);
                        buf[strlen(wdLines[i].c_str())] = '\0';
                        Rio_writen(connfd, buf, 80);
                    }
                }
                
            }
            else if (req_type != "quit") {
                resp.status = htonl(2);
                if (req_type == "clist") Rio_writen(connfd, &resp.status, 4);
            }
            
            //-----------Send Response-----------
            Rio_writen(connfd, &resp.status, 4);
            if (ntohl(resp.status)==0 && req_type == "cget")
                Rio_writen(connfd, &resp, 4 + ntohl(resp.size));
            
            //-----------Print Status-----------
            if (secret == ntohl(req.secret)) {
                cout << "-------------------------------------------"   << endl;
                cout << "Request Type       = " << req_type             << endl;
                cout << "Secret Key         = " << ntohl(req.secret)    << endl;
                cout << "Filename           = " << req.filename         << endl;
                cout << "Operation Status   = " << ntohl(resp.status)   << endl;
                cout << "-------------------------------------------"   << endl;
            }
            
            resp = {};
            req = {};
        }
    }
    
    Close(connfd);
    cout << "Server socket closed." << endl;
    exit(0);
}
